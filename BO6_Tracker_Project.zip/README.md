# BO6 Aim Assist

## تشغيل محليًا
1. ثبت Python 3.10+ وأضفها للـ PATH.
2. من CMD في مجلد المشروع:
   ```
   setup_tracker.bat
   ```
3. الناتج: `dist\BO6_AimAssist.exe`

## CI/CD عبر GitHub Actions
- ملف `.github/workflows/build.yml` يجهز EXE تلقائيًا عند الدفع للفرع main.
